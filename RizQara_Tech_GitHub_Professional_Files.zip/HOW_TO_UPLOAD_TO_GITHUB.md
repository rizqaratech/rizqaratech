# How to Upload These Files to GitHub

## For the Company Profile README

1. Go to GitHub.
2. Create a new public repository named exactly:

```text
rizqaratech
```

3. Upload these files:

```text
README.md
LICENSE
CONTRIBUTING.md
SECURITY.md
CODE_OF_CONDUCT.md
CHANGELOG.md
.gitignore
.env.example
assets/rizqara-tech-logo.png
```

4. Commit with this message:

```text
Add professional RizQara Tech GitHub profile documentation
```

After this, the README will show on the RizQara Tech GitHub profile.

---

## For Each Project Repository

Add these files to every important project repository:

```text
README.md
LICENSE
CONTRIBUTING.md
SECURITY.md
CODE_OF_CONDUCT.md
CHANGELOG.md
.gitignore
.env.example
```

For project-specific README files, use:

```text
templates/REPOSITORY_README_TEMPLATE.md
```

Copy it into the project repo as `README.md` and edit project details.

---

## Important Security Reminder

Never upload real `.env` files, passwords, API keys, database credentials, admin credentials, or client private data.
